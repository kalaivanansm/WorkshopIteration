//
//  shopperPresenter.swift
//  IterationOne
//
//  Created by Kalaivanan on 20/12/19.
//  Copyright © 2019 Kalaivanan. All rights reserved.
//

import UIKit

class shopperPresenter: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func constructURLRequest(serviceUrl: String, httpMethod: String) -> URLRequest? {
        let Url = String(format: serviceUrl)
        let serviceUrl = URL(string: Url)
        var request = URLRequest(url: serviceUrl!)
        request.httpMethod = httpMethod
        request.setValue(shopperConstant.applicationConstant, forHTTPHeaderField: shopperConstant.contentType)
        return request
    }
    
    func constructJson(response: Data) -> [shopperModel] {
        do {
            let decoder = JSONDecoder()
            let launch = try decoder.decode([shopperModel].self, from: response)
            for items in launch {
                items.cartValue = 0
            }
            return launch
        } catch {
            
        }
        return [shopperModel]()
    }
    
    func increaseValueInCart(sender: UIButton, productItem: shopperModel) -> Int {
        var arrayValue: Int = productItem.cartValue ?? 0
        if arrayValue >= 0 {
            arrayValue += 1
        }
        return arrayValue
    }
    
    func removeValueFromCart(sender: UIButton, productItem: shopperModel) -> Int {
        var arrayValue: Int = productItem.cartValue ?? 0
        if arrayValue > 0 {
            arrayValue -= 1
        }
        return arrayValue
    }
}
