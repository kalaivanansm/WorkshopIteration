//
//  NetworkConnection.swift
//  IterationOne
//
//  Created by Kalaivanan on 20/12/19.
//  Copyright © 2019 Kalaivanan. All rights reserved.
//

import Foundation

protocol serviceDelegate: AnyObject {
    func onSuccessResponse(shopperData: Data)
    func onfailureResponse()
}

class NetworkConnection {
    weak var delegate: serviceDelegate?
    
    func makeRequest(urlRequest: URLRequest) {
        let request = urlRequest
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let data = data {
                self.delegate?.onSuccessResponse(shopperData: data)
            } else {
                self.delegate?.onfailureResponse()
            }
            }.resume()
    }
}
