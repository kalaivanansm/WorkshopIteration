//
//  shopperConstant.swift
//  IterationOne
//
//  Created by Kalaivanan on 20/12/19.
//  Copyright © 2019 Kalaivanan. All rights reserved.
//

import Foundation

struct shopperConstant {
    static let shopperBaseURL: String = "http://www.mocky.io/v2/5dfb59e72f00006200ff9e80"
    static let applicationConstant: String = "Application/json"
    static let contentType: String = "Content-Type"
    static let productImage: String = "productImage"
}
