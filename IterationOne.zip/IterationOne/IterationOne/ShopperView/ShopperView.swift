//
//  ViewController.swift
//  IterationOne
//
//  Created by Kalaivanan on 20/12/19.
//  Copyright © 2019 Kalaivanan. All rights reserved.
//

import UIKit

class ShopperView: UIViewController {
    @IBOutlet weak var producTable: UITableView!
    var products: [shopperModel] = []
    var networkPresenter = NetworkConnection()
    var presenter = shopperPresenter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        networkPresenter.delegate = self
        if let urlRequest = presenter.constructURLRequest(serviceUrl: shopperConstant.shopperBaseURL, httpMethod: "GET") {
            self.networkPresenter.makeRequest(urlRequest: urlRequest)
        }
    }
}

extension ShopperView: serviceDelegate {
    func onSuccessResponse(shopperData: Data) {
        DispatchQueue.main.async {
            let constructedValue = shopperPresenter().constructJson(response: shopperData)
            self.products = constructedValue
            self.producTable.reloadData()
        }
    }
    
    func onfailureResponse() {
        print("error")
    }
}

extension ShopperView: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "shopCell", for: indexPath) as! ShopperCell
        let productValue = self.products[indexPath.row]
        cell.setValueForCell(productValue: productValue, indexPath: indexPath)
        cell.addButton.addTarget(self, action: #selector(self.addItemsToCart), for: .touchUpInside)
        cell.removeButton.addTarget(self, action: #selector(self.removeItemsFromCart), for: .touchUpInside)
        return cell
    }
    
    @objc func addItemsToCart(sender: UIButton) {
        let productItem = products[sender.tag]
        products[sender.tag].cartValue = self.presenter.increaseValueInCart(sender: sender, productItem: productItem)
        self.producTable.reloadData()
    }
    
    @objc func removeItemsFromCart(sender: UIButton) {
        let productItem = products[sender.tag]
        products[sender.tag].cartValue = self.presenter.removeValueFromCart(sender: sender, productItem: productItem)
        self.producTable.reloadData()
    }
}

