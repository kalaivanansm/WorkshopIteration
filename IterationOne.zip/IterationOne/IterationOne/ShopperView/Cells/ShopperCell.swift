//
//  ShopperCell.swift
//  IterationOne
//
//  Created by Kalaivanan on 20/12/19.
//  Copyright © 2019 Kalaivanan. All rights reserved.
//

import UIKit

class ShopperCell: UITableViewCell {
    
    @IBOutlet weak var shopperImage: UIImageView!
    @IBOutlet weak var shoppetitle: UILabel!
    @IBOutlet weak var shopperPrice: UILabel!
    @IBOutlet weak var cardItemNumber: UILabel!
    @IBOutlet weak var removeButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func setValueForCell(productValue: shopperModel, indexPath: IndexPath) {
        shoppetitle.text = productValue.name
        shopperPrice.text = productValue.offerPrice?.isEmpty ?? true ? productValue.price : productValue.offerPrice
        shopperPrice.textColor = productValue.offerPrice?.isEmpty ?? true ? UIColor.lightGray : UIColor.orange
        shopperImage.image = UIImage(named: shopperConstant.productImage)
        addButton.tag = indexPath.row
        removeButton.tag = indexPath.row
        if let cartValue = productValue.cartValue?.description {
             cardItemNumber.text = "(" + cartValue + ")"
        }
    }
}
