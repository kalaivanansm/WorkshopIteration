//
//  ShopperModel.swift
//  IterationOne
//
//  Created by Kalaivanan on 20/12/19.
//  Copyright © 2019 Kalaivanan. All rights reserved.
//

import Foundation

enum offerAvailable {
    case available
    case notAvailable
}

class shopperModel: Codable {
    let name: String?
    let price: String?
    let image: String?
    let pid: String?
    let offerPrice: String?
    let desc: String?
    var cartValue: Int?
    
    init(name: String, price: String, image: String, pid: String, offerPrice: String, desc: String, cartValue: Int)  {
        self.name = name
        self.price = price
        self.image = image
        self.pid = pid
        self.offerPrice = offerPrice
        self.desc = desc
        self.cartValue = cartValue
    }
}
